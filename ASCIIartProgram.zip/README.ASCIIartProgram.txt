TITLE: Happy Umbrella
AUTHOR/PROGRAMMER: Aika Washington
DATE DUE: 08/30/17
DATE SUBMITTED: 08/29/17
COURSE TITLE: AP Computer Science
MEETING TIME(S): 10:00am MWF
DESCRIPTION: This is a Java program that prints an ASCII Art picture of a happy umbrella when ran.
HONOR CODE: On my honor, I have neither given nor received any unauthorized aid on this assingment. Aika Washington
HOWTO: Open the program with the IDE of your choice that supports Java. Compile then run the program.
INPUT FILE: N/A
OUTPUT FILE: N/A
BIBLIOGRAPHY: asciiflow.com
RESOURCES: N/A
COMMENTS: N/A
REFLECTION: I spread this project out over two days, I started the beginning of it one evening and finished the rest the next night. My biggest challenge was getting everything aligned while also having to use escape characters, so that caused a small need for adjustment, which I was able to overcome through constantly re-running the code to check and see if everything was aligned.